(function () {
  const register = async () => {
    await navigator.serviceWorker.register("/scramjet.sw.js");
  };
  window.scramjet = { loadWorker: register };
})();