self.__scramjet = {
  backend: "https://your-baremux-worker.workers.dev/",
  bareMux: { version: 3, path: "/bare/" },
};